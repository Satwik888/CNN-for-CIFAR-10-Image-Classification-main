# CNN-for-CIFAR-10-Image-Classification
The main objective is to apply deep learning techniques for accurate image recognition and evaluate model performance using standard metrics.
